//
//  Person.swift
//  GanserAudric-hw4
//
//  Created by Audric Ganser on 2/16/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import Foundation

class Person {
    public var firstName:String = ""
    public var lastName:String = ""
    public var age:Int = 0
    public var street:String = ""
    public var city:String = ""
    public var state:String = ""
    public var zip:Int = 0
    
    init(firstName:String, lastName:String, age:Int, street:String, city:String, state:String, zip:Int) {
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
        self.street = street
        self.city = city
        self.state = state
        self.zip = zip
    }
    
}
