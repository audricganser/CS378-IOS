//
//  ContactTableViewController.swift
//  GanserAudric-hw4
//
//  Created by Audric Ganser on 2/16/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class ContactTableViewController: UITableViewController {
    
    @IBOutlet var contactTableView: UITableView!
    private var people = [Person]()
    
    var alertController:UIAlertController? = nil
    
    @IBAction func button(_ sender: UIButton) {
        let point = tableView.convert(CGPoint.zero, from: sender)
        let indexArray = tableView.indexPathForRow(at: point)!
        let index = indexArray[0]
        
        self.alertController = UIAlertController(title: "Person", message: "\(people[index].firstName) \(people[index].lastName) \(people[index].age)", preferredStyle: UIAlertControllerStyle.alert)
        
        let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
        }
        self.alertController!.addAction(OKAction)
        
        self.present(self.alertController!, animated: true, completion:nil)

    }
    
    private func createDataModel() {
        
        people.append(Person(firstName: "Joe", lastName: "Johnson", age: 35, street: "1 main street",city: "Austin", state: "TX", zip: 78128))
        people.append(Person(firstName: "Sam", lastName: "Smith", age: 27, street: "2 main street",city: "Austin", state: "TX", zip: 78228))
        people.append(Person(firstName: "Sue", lastName: "Jefferson", age: 52, street: "3 main street",city: "Austin", state: "TX", zip: 78328))
        people.append(Person(firstName: "Zoey", lastName: "Zimmerman", age: 17, street: "4 main street",city: "Austin", state: "TX", zip: 78428))
        people.append(Person(firstName: "Alan", lastName: "Albright", age: 83, street: "5 main street",city: "Austin", state: "TX", zip: 78528))
        people.append(Person(firstName: "Chris", lastName: "Chambers", age: 33, street: "6 main street",city: "Austin", state: "TX", zip: 78628))
        people.append(Person(firstName: "Danny", lastName: "Donaldson", age: 6, street: "7 main street",city: "Austin", state: "TX", zip: 78728))
        people.append(Person(firstName: "Eli", lastName: "Edgerton", age: 10, street: "8 main street",city: "Austin", state: "TX", zip: 78828))
        people.append(Person(firstName: "Frank", lastName: "Farmer", age: 100, street: "9 main street",city: "Austin", state: "TX", zip: 78928))
    }

    override func viewDidLoad() {
        super.viewDidLoad(createDataModel())

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 9
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row % 2 != 0 {
            let addressCell = tableView.dequeueReusableCell(withIdentifier: "addressid", for: indexPath) as!
            AddressTableViewCell
            
            addressCell.street.text = "\(people[indexPath.section].street)"
            addressCell.city.text = "\(people[indexPath.section].city)"
            addressCell.state.text = "\(people[indexPath.section].state)"
            addressCell.zip.text = "\(String(people[indexPath.section].zip))"
            
            return addressCell
        }
        
        let nameCell = tableView.dequeueReusableCell(withIdentifier: "nameid", for: indexPath) as!
        NameTableViewCell
        
        nameCell.firstName.text = "\(people[indexPath.section].firstName)"
        nameCell.lastName.text = "\(people[indexPath.section].lastName)"
        
        return nameCell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
