//
//  AddCandidateViewController.swift
//  GanserAudric-hw5
//
//  Created by Audric Ganser on 2/21/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit
import CoreData

class AddCandidateViewController: UIViewController {

    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var state: UITextField!
    @IBOutlet weak var party: UISegmentedControl!
    @IBOutlet weak var savedLabel: UILabel!
    
    var alertController:UIAlertController? = nil
    
    //text label string
    var saved = ""
    
    var candidates = [NSManagedObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        savedLabel.text = saved
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func saveCandidate(_ sender: Any) {
        let firstNameTextField = self.firstName
        let lastNameTextField = self.lastName
        let stateTextField = self.state
        let partySegmentedField = self.party.titleForSegment(at: (self.party?.selectedSegmentIndex)!)!
        
        let error = errorCheck(firstName: firstNameTextField!.text!, lastName: lastNameTextField!.text!, state: stateTextField!.text!)
        
        if !error {
            self.saveCandidate(firstName: firstNameTextField!.text!, lastName: lastNameTextField!.text!, state: stateTextField!.text!, party: partySegmentedField)
            
            //hides keyboard once candidate is saved
            self.view.endEditing(true)
            
            savedLabel.text = "Candidate Saved!"
        }
    }
    
    //checks if data has been filled in
    func errorCheck(firstName: String, lastName: String, state: String) -> Bool {
        if firstName == "" || lastName == "" || state == "" {
            self.alertController = UIAlertController(title: "Alert", message: "You must enter a value for all fields.", preferredStyle: UIAlertControllerStyle.alert)
            
            let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
            }
            self.alertController!.addAction(OKAction)
            
            self.present(self.alertController!, animated: true, completion:nil)
            
            return true
        }
        return false
    }

    fileprivate func saveCandidate(firstName: String, lastName: String, state: String, party: String) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        // Create the entity we want to save
        let entity =  NSEntityDescription.entity(forEntityName: "Candidate", in: managedContext)
        
        let candidate = NSManagedObject(entity: entity!, insertInto: managedContext)
        
        // Set the attribute values
        candidate.setValue(firstName, forKey: "firstName")
        candidate.setValue(lastName, forKey: "lastName")
        candidate.setValue(state, forKey: "state")
        candidate.setValue(party, forKey: "party")
        
        // Commit the changes.
        do {
            try managedContext.save()
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            print("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        // Add the new entity to our array of managed objects
        candidates.append(candidate)
    }
    
    //when clicked outside of the keyboard it becomes hidden
    override func touchesBegan (_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
