//
//  AddEmployeeViewController.swift
//  GanserAudric-hw8
//
//  Created by Audric Ganser on 4/5/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class AddEmployeeViewController: UIViewController {

    @IBOutlet weak var fname: UITextField!
    @IBOutlet weak var lname: UITextField!
    @IBOutlet weak var dept: UITextField!
    @IBOutlet weak var jtitle: UITextField!
    
    var alertController:UIAlertController? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func addEmployee(_ sender: Any) {
        let firstName = self.fname.text!
        let lastName = self.lname.text!
        let department = self.dept.text!
        let jobTitle = self.jtitle.text!
        
        let pass:Bool = errorCheck(firstName: firstName, lastName: lastName, department: department, jobTitle: jobTitle)
        
        if(pass) {
            let dataDict = ["firstName":firstName, "lastName":lastName, "department":department, "jobTitle": jobTitle];
            
            // Post the notification. send along the data.
            // We don't know who, if anyone, is listening. Nor should we care. We're just notifying.
            NotificationCenter.default.post(name: Notification.Name(rawValue: event1Key), object: nil, userInfo: dataDict)

            self.alertController = UIAlertController(title: "Add Employee", message: "Employee has been added!!", preferredStyle: UIAlertControllerStyle.alert)
            
            let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
            }
            self.alertController!.addAction(OKAction)
            
            self.present(self.alertController!, animated: true, completion:nil)
        }
        
    }
    
    //checks if data has been filled in
    func errorCheck(firstName: String, lastName: String, department: String, jobTitle: String) -> Bool {
        if firstName == "" || lastName == "" || department == "" || jobTitle == "" {
            self.alertController = UIAlertController(title: "Error", message: "Please fill in all the values", preferredStyle: UIAlertControllerStyle.alert)
            
            let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (action:UIAlertAction) in
            }
            self.alertController!.addAction(OKAction)
            
            self.present(self.alertController!, animated: true, completion:nil)
            
            return false
        }
        return true
    }

    
    //when clicked outside of the keyboard it becomes hidden
    override func touchesBegan (_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
