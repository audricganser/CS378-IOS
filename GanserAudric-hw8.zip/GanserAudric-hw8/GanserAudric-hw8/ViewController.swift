//
//  ViewController.swift
//  GanserAudric-hw8
//
//  Created by Audric Ganser on 4/5/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var employees = [Employee]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Define an observer for the notification
        NotificationCenter.default.addObserver(self, selector: #selector(handler1(notification:)), name: NSNotification.Name(rawValue: event1Key), object: nil)

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // This handler definition has both the external and internal
    // argument name as 'notification'.
    func handler1(notification: Notification) {
        // extract the data that was sent in the notification
        let dataDict:Dictionary<String,String> = notification.userInfo as! Dictionary<String,String>
        
        let data1 = dataDict["firstName"]!
        let data2 = dataDict["lastName"]!
        let data3 = dataDict["department"]!
        let data4 = dataDict["jobTitle"]!
        
        
        let employee = Employee.init(_fname: data1, _lname: data2, _dept: data3, _jtitle: data4)
        
        employees.append(employee)
        
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if(segue.identifier == "showSegue") {
            let destinationVC = segue.destination as! ShowEmployeeTableViewController
            destinationVC.employeesSegue = employees
        }
    }


}

