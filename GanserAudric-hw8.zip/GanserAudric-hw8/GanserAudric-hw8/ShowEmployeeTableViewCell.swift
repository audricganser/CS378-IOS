//
//  ShowEmployeeTableViewCell.swift
//  GanserAudric-hw8
//
//  Created by Audric Ganser on 4/5/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class ShowEmployeeTableViewCell: UITableViewCell {

    @IBOutlet weak var fname: UILabel!
    @IBOutlet weak var lname: UILabel!
    @IBOutlet weak var dept: UILabel!
    @IBOutlet weak var jtitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
