//
//  NotificationKeys.swift
//  GanserAudric-hw8
//
//  Created by Audric Ganser on 4/7/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import Foundation

// Define one constant for each notification in the app
let event1Key = "event1Key"
