//
//  Employee.swift
//  GanserAudric-hw8
//
//  Created by Audric Ganser on 4/5/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import Foundation

class Employee : NSObject {
    var _fname:String
    var _lname:String
    var _dept:String
    var _jtitle:String
    
    init(_fname:String, _lname:String, _dept:String, _jtitle:String) {
        self._fname = _fname
        self._lname = _lname
        self._dept = _dept
        self._jtitle = _jtitle
    }
    
}
