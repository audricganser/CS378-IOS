//
//  ViewController.swift
//  GanserAudric-hw7
//
//  Created by Audric Ganser on 3/20/17.
//
//

import UIKit

class ViewController: UIViewController {
    
    var slide:CGFloat = -50
    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //tap gestures
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapHandler(_:)))
        self.label.isUserInteractionEnabled = true
        self.label.addGestureRecognizer(tapGesture)
        
        //swipe gestures
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.handleSwipes))
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.handleSwipes))
        
        leftSwipe.direction = .left
        rightSwipe.direction = .right
        
        view.addGestureRecognizer(leftSwipe)
        view.addGestureRecognizer(rightSwipe)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tapHandler(_ sender: UITapGestureRecognizer) {
        
        let rightBounds:CGFloat = self.view.bounds.width - 49
        let stepsToMove:CGFloat = 50
        
        UIView.animate(withDuration: 0.50, delay: 0.0, options: [.curveLinear], animations: {
            
            self.label.center.x += self.slide

            if self.label.center.x < 76 {
                
                self.slide = stepsToMove
                self.label.center.x = 49
            }
            
            if self.label.center.x > rightBounds {
                
                self.label.center.x = rightBounds
                self.slide = -stepsToMove
            }
            
            
        }, completion: nil)
    }
    
    func handleSwipes(sender:UISwipeGestureRecognizer) {
        
        if sender.direction == .left {
            
            UIView.animate(withDuration: 0.75, delay: 0.0, options: [.curveLinear], animations: {
                
                self.label.center.x -= self.label.center.x + 49
                
            }, completion: nil)

        }
        
        if sender.direction == .right {
            
            UIView.animate(withDuration: 0.75, delay: 0.0, options: [.curveLinear], animations: {
                
                self.label.center.x += self.view.bounds.width - self.label.center.x + 49
            
            }, completion: nil)
            
        }
    }
}

