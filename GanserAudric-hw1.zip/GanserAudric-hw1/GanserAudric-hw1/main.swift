//
//  main.swift
//  GanserAudric-hw1
//
//  Created by Audric Ganser on 1/23/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import Foundation

func main() {
    var car1 = Automobile.create(_make: "Masarati", _model: "GranTurismo", _numberOfDoors: 2, _speed: 0)
    var car2 = Automobile.create(_make: "Honda", _model: "Accord", _numberOfDoors: 4, _speed: 0)
    var car3 = Automobile.create(_make: "Tesla", _model: "S 90", _numberOfDoors: 2, _speed: 0)
    
    func randomValueBetween(min:UInt32, max:UInt32) -> UInt32 {
        let randomValue:UInt32 = min + arc4random_uniform(UInt32(max - min + 1))
        return randomValue
    }
    
    var index = 0
    while index < 10 {
        car1.increaseSpeed(_speedChange: Int(randomValueBetween(min: 0, max: 16)))
        car2.increaseSpeed(_speedChange: Int(randomValueBetween(min: 0, max: 16)))
        car3.increaseSpeed(_speedChange: Int(randomValueBetween(min: 0, max: 16)))
        index += 1
    }
    
    var speedWinnerMake:String
    var winnerModel:String
    
    var car1Win:Bool = false
    var car2Win:Bool = false
    var car3Win:Bool = false
    var raceTie:Bool = false
    
    if car1.speed > car2.speed && car1.speed > car3.speed {
        speedWinnerMake = car1.make
        winnerModel = car1.model
        car1Win = true
    }
    else if car3.speed < car2.speed {
        speedWinnerMake = car2.make
        winnerModel = car2.model
        car2Win = true
    }
    else {
        speedWinnerMake = car3.make
        winnerModel = car3.model
        car3Win = true
    }
    
    print (car1.description())
    print (car2.description())
    print (car3.description())
    
    if car3Win {
        if car3.speed == car1.speed || car3.speed == car2.speed {
            print("There was a tie!!")
            raceTie = true
        }
    }
    if car2Win {
        if car2.speed == car1.speed || car2.speed == car3.speed {
            print("There was a tie!!")
            raceTie = true
        }
    }
    if car1Win {
        if car1.speed == car2.speed || car1.speed == car3.speed {
            print("There was a tie!!")
            raceTie = true
        }
    }
    if raceTie == false {
        print ("\(speedWinnerMake) \(winnerModel) Won!!")
    }
    
}

main()


