//
//  Automobile.swift
//  GanserAudric-hw1
//
//  Created by Audric Ganser on 1/23/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import Foundation

class Automobile {
    private var _make:String
    var make:String {
        get {
            return _make
        }
        set (newVal) {
            _make = newVal
        }
    }
    
    private var _model:String
    var model:String {
        get {
            return _model
        }
        set (newVal) {
            _model = newVal
        }
    }

    private var _numberOfDoors:Int
    var numberOfDoors:Int {
        get {
            return _numberOfDoors
        }
        set (newVal) {
            _numberOfDoors = newVal
        }
    }

    private var _speed:Int
    var speed:Int {
        get {
            return _speed
        }
    }
    
    init(_make:String, _model:String, _numberOfDoors:Int, _speed:Int) {
        self._make = _make
        self._model = _model
        self._numberOfDoors = _numberOfDoors
        self._speed = _speed
    }
    
    class func create(_make:String, _model:String, _numberOfDoors:Int, _speed:Int) -> Automobile {
        return Automobile(_make:_make,
                          _model:_model,
                          _numberOfDoors:_numberOfDoors,
                          _speed:_speed)
    }
    
    func increaseSpeed(_speedChange:Int) {
        let newSpeed:Int = _speed + _speedChange
        if newSpeed >= 0 && newSpeed <= 150 {
            _speed = newSpeed
        }
    }
    
    func decreaseSpeed(_speedChange:Int) {
        let newSpeed:Int = _speed - _speedChange
        if newSpeed >= 0 && newSpeed <= 150 {
            _speed = newSpeed
        }
    }
    
    func description() -> String {
        return "Make: \(_make), Model: \(_model), Number of Door: \(_numberOfDoors), Speed: \(_speed)"
    }
    
}
