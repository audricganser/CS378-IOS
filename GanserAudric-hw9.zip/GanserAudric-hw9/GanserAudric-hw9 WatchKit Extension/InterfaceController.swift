//
//  InterfaceController.swift
//  GanserAudric-hw9 WatchKit Extension
//
//  Created by Audric Ganser on 4/24/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var label: WKInterfaceLabel!
    
    var text = ["My First", "iWatch App", "YAY!"]
    var index = 0
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        label.setText(text[index])
        //index += 1
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func nextButton() {
        if index == text.count - 1 {
            index = 0
        }
        else {
            index += 1
        }
        label.setText(text[index])
    }

}
