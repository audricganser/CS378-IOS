//
//  MyPageViewController.swift
//  GanserAudric-hw6
//
//  Created by Audric Ganser on 3/7/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class MyPageViewController: UIPageViewController {
        
    fileprivate(set) lazy var orderedViewControllers: [UIViewController] = {
        return [self.newImageViewController(_image: "wonders1"),
                self.newImageViewController(_image: "wonders2"),
                self.newImageViewController(_image: "wonders3"),
                self.newImageViewController(_image: "wonders4"),
                self.newImageViewController(_image: "wonders5"),
                self.newImageViewController(_image: "wonders6"),
                self.newImageViewController(_image: "wonders7")]
    }()
    
    // Include this method to be able to programmatically choose the transition style.
    // Choose between:  .scroll (default) and .pageCurl
    required init?(coder aDecoder: NSCoder) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataSource = self
        
        // Get the first view controller from the array of view controllers,
        // and use it to establish the initial array of view controllers
        // that will be managed by the page view controller.
        if let firstViewController = orderedViewControllers.first {
            setViewControllers([firstViewController],
                               direction: .forward,
                               animated: true,
                               completion: nil)
        }
        
        let pageControl = UIPageControl.appearance()
        pageControl.pageIndicatorTintColor = UIColor.white
        pageControl.currentPageIndicatorTintColor = UIColor.green
        pageControl.backgroundColor = UIColor.gray
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    fileprivate func newImageViewController(_image: String) -> UIViewController {
        // Instantiate a view controller that is in the storyboard, using the
        // associated storyboard id - which can be set in the Identity Inspector.
        // "Main" here is the name of the storyboard file.
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "imageVC") as? ImageViewController
        viewController!.fileName = _image
        return viewController!
    }
}

// MARK: UIPageViewControllerDataSource

extension MyPageViewController: UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        let previousIndex = viewControllerIndex - 1
        
        guard previousIndex >= 0 else {
            return orderedViewControllers[6]
        }
        return orderedViewControllers[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = orderedViewControllers.index(of: viewController) else {
            return nil
        }
        
        var nextIndex = 0
        
        if !(viewControllerIndex == 6) {
            nextIndex = viewControllerIndex + 1
        }
        
        guard orderedViewControllers.count != nextIndex else {
            return nil
        }
        return orderedViewControllers[nextIndex]
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return orderedViewControllers.count
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        guard let firstViewController = viewControllers?.first,
            let firstViewControllerIndex = orderedViewControllers.index(of: firstViewController) else {
                return 0
        }
        return firstViewControllerIndex
    }
}
