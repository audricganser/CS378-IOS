//
//  ImageViewController.swift
//  GanserAudric-hw6
//
//  Created by Audric Ganser on 3/7/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {
        
    @IBOutlet weak var imageView: UIImageView!
    var fileName: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.imageView.image = UIImage(named: fileName!)
        // Set colors for the page control.
        // We're setting the global page control appearance object.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
