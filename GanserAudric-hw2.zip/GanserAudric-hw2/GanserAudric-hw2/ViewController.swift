//
//  ViewController.swift
//  GanserAudric-hw2
//
//  Created by Audric Ganser on 1/30/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var cityField: UITextField!
    @IBOutlet weak var messageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.nameField.delegate = self
        self.cityField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClickedSaved(_ sender: Any) {
        self.view.endEditing(true)
        if(nameField.text! == "" || cityField.text! == "") {
            messageLabel.text = "You must enter a value for *both* name and city!!"
        } else {
            messageLabel.text = "\(nameField.text!) - \(cityField.text!)"
        }
    }
    
    //hides keyboard when click on return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true;
    }
    
    //when clicked outside of the keyboard it becomes hidden
    override func touchesBegan (_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}

