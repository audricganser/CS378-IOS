//
//  PersonViewController.swift
//  GanserAudric-hw3
//
//  Created by Audric Ganser on 2/13/17.
//  Copyright © 2017 Audric Ganser. All rights reserved.
//

import UIKit

class PersonViewController: UIViewController {

    @IBOutlet weak var firstNameSegue: UILabel!
    @IBOutlet weak var lastNameSegue: UILabel!
    @IBOutlet weak var ageSegue: UILabel!
    @IBOutlet weak var citySegue: UILabel!
    
    var firstNameViaSegue = ""
    var lastNameViaSegue = ""
    var ageViaSegue = ""
    var cityViaSegue = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNameSegue.text = firstNameViaSegue
        lastNameSegue.text = lastNameViaSegue
        ageSegue.text = ageViaSegue
        citySegue.text = cityViaSegue
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
